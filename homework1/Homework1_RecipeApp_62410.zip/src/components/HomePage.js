import React from 'react'
import PropTypes from 'prop-types'
import Menu from '../components/Menu'
import './HomePage.css'
import { Typography } from '@material-ui/core'

function HomePage() {
  return (
    <div className="bg">
 
        <Menu/>
    </div>
  )
}


export default HomePage
